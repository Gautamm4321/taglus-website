"use client";


export default function AboutHero() {
  return (
    <section className="relative w-full pt-28 sm:pt-36 pb-8 lg:pt-20 lg:pb-0 lg:min-h-screen lg:flex lg:flex-col lg:justify-center px-6 sm:px-10 lg:px-12 max-w-7xl mx-auto select-none">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/4 left-1/4 -translate-y-1/2 w-[70vw] xl:w-[800px] h-[450px] bg-sky-500/10 blur-[150px] pointer-events-none -z-10" />

      {/* ================= TOP SECTION: LEFT-ALIGNED ================= */}
      <div className="max-w-4xl text-left space-y-5 ">
        {/* Category Pill */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.04] border border-[#E8DCC8]/25 text-sky-300 text-xs font-semibold tracking-widest uppercase backdrop-blur-md">
          <span>About Taglus</span>
        </div>

        {/* 1-Line Headline */}
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight text-[#E8DCC8] xl:whitespace-nowrap">
          Your Complete Digital Orthodontic Partner
        </h1>

        {/* 2-Line Subheading */}
        <p className="text-base sm:text-lg text-sky-300/90 font-mono font-medium leading-relaxed max-w-2xl">
          One partner for the full digital aligner and retainer workflow: <br className="hidden sm:inline" />
          materials, machines, resins and accessories.
        </p>

        {/* Body Text */}
        <div className="space-y-4 pt-1 text-base sm:text-lg text-[#E8DCC8] font-normal leading-relaxed max-w-3xl">
          <p>
            Taglus is an ISO 13485:2016 certified manufacturer of digital orthodontic consumables and equipment, trusted by clinics, labs and distributors in 70+ countries. We began by making advanced thermoplastic aligner and retainer sheets. Today our range covers every step of the digital workflow, from printing the model to delivering the finished appliance.
          </p>
          <p>
            Every product is engineered to work together, so our partners get consistent results, a simpler supply chain and one team to call for support.
          </p>
        </div>
      </div>

    </section>
  );
}